jQuery(document).ready(function () {
    "use strict";
        
    // home text slider
    $('.select2').select2();

})




